package com.example.ilauncher.ui

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.telephony.TelephonyManager
import android.text.format.DateFormat
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsIgnoringVisibility
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsTopHeight
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.ilauncher.ui.theme.IosGreen
import com.example.ilauncher.ui.theme.IosRed
import kotlinx.coroutines.delay
import java.util.Date

/**
 * Thanh trạng thái kiểu iOS: giờ bên trái; sóng, Wi-Fi, pin bên phải.
 * Chỉ hiển thị trong launcher (thanh của hệ thống bị ẩn khi ở màn hình chính).
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun IosStatusBar(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var time by remember { mutableStateOf(DateFormat.getTimeFormat(context).format(Date())) }
    var batteryLevel by remember { mutableFloatStateOf(1f) }
    var charging by remember { mutableStateOf(false) }
    var onWifi by remember { mutableStateOf(false) }
    var signal by remember { mutableIntStateOf(4) }

    // Giờ + cường độ sóng: cập nhật đúng đầu phút, sóng mỗi ~10 giây
    LaunchedEffect(Unit) {
        val tm = context.getSystemService(TelephonyManager::class.java)
        while (true) {
            time = DateFormat.getTimeFormat(context).format(Date())
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                signal = runCatching { tm?.signalStrength?.level }.getOrNull() ?: signal
            }
            val untilNextMinute = 60_000L - System.currentTimeMillis() % 60_000L
            delay(untilNextMinute.coerceAtMost(10_000L))
        }
    }

    // Pin + Wi-Fi theo thời gian thực
    DisposableEffect(Unit) {
        val batteryReceiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                if (level >= 0 && scale > 0) batteryLevel = level / scale.toFloat()
                val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                    status == BatteryManager.BATTERY_STATUS_FULL
            }
        }
        ContextCompat.registerReceiver(
            context, batteryReceiver,
            IntentFilter(Intent.ACTION_BATTERY_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED,
        )

        val cm = context.getSystemService(ConnectivityManager::class.java)
        val netCallback = object : ConnectivityManager.NetworkCallback() {
            override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
                onWifi = caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
            }
            override fun onLost(network: Network) {
                onWifi = false
            }
        }
        runCatching { cm.registerDefaultNetworkCallback(netCallback) }

        onDispose {
            runCatching { context.unregisterReceiver(batteryReceiver) }
            runCatching { cm.unregisterNetworkCallback(netCallback) }
        }
    }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .fillMaxWidth()
            .windowInsetsTopHeight(WindowInsets.statusBarsIgnoringVisibility)
            .padding(horizontal = 30.dp),
    ) {
        Text(time, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.weight(1f))
        CellularBars(signal)
        Spacer(Modifier.width(6.dp))
        if (onWifi) {
            Icon(Icons.Rounded.Wifi, contentDescription = "Wi-Fi", tint = Color.White, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
        }
        BatteryIcon(batteryLevel, charging)
    }
}

@Composable
private fun CellularBars(level: Int) {
    Canvas(Modifier.size(width = 18.dp, height = 11.dp)) {
        val gap = 1.5.dp.toPx()
        val barW = (size.width - gap * 3) / 4
        val heights = floatArrayOf(0.35f, 0.55f, 0.77f, 1f)
        for (i in 0 until 4) {
            val h = size.height * heights[i]
            drawRoundRect(
                color = if (i < level) Color.White else Color.White.copy(alpha = 0.35f),
                topLeft = Offset(i * (barW + gap), size.height - h),
                size = Size(barW, h),
                cornerRadius = CornerRadius(1.dp.toPx()),
            )
        }
    }
}

@Composable
private fun BatteryIcon(level: Float, charging: Boolean) {
    val fill = when {
        charging -> IosGreen
        level <= 0.2f -> IosRed
        else -> Color.White
    }
    Canvas(Modifier.size(width = 27.dp, height = 13.dp)) {
        val stroke = 1.dp.toPx()
        val nubW = 1.8.dp.toPx()
        val bodyW = size.width - nubW - 1.dp.toPx()
        val outline = Color.White.copy(alpha = 0.45f)

        drawRoundRect(
            color = outline,
            topLeft = Offset(stroke / 2, stroke / 2),
            size = Size(bodyW - stroke, size.height - stroke),
            cornerRadius = CornerRadius(4.dp.toPx()),
            style = Stroke(stroke),
        )
        val pad = 2.dp.toPx()
        drawRoundRect(
            color = fill,
            topLeft = Offset(pad, pad),
            size = Size((bodyW - pad * 2) * level.coerceIn(0.06f, 1f), size.height - pad * 2),
            cornerRadius = CornerRadius(2.dp.toPx()),
        )
        drawRoundRect(
            color = outline,
            topLeft = Offset(bodyW + 1.dp.toPx() - stroke, size.height * 0.33f),
            size = Size(nubW, size.height * 0.34f),
            cornerRadius = CornerRadius(1.dp.toPx()),
        )
    }
}
