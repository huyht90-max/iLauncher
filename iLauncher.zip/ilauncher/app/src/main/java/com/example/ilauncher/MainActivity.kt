package com.example.ilauncher

import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.example.ilauncher.ui.LauncherRoot
import com.example.ilauncher.ui.theme.LauncherTheme
import kotlinx.coroutines.flow.MutableSharedFlow

class MainActivity : ComponentActivity() {

    /** Phát sự kiện khi người dùng bấm nút Home lúc đang ở launcher. */
    private val homeEvents = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    private var lastWindowBlur = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        super.onCreate(savedInstanceState)

        setContent {
            LauncherTheme {
                LauncherRoot(
                    homeEvents = homeEvents,
                    windowBlurSupported = supportsWindowBlur(),
                    onWindowBlur = ::setWindowBlur,
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN) homeEvents.tryEmit(Unit)
    }

    private fun supportsWindowBlur(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return false
        return getSystemService(WindowManager::class.java).isCrossWindowBlurEnabled
    }

    /**
     * Làm mờ hình nền hệ thống nằm phía sau cửa sổ launcher (Android 12+).
     * Một số máy/chế độ tiết kiệm pin tắt tính năng này -> chỉ còn lớp tối mờ.
     */
    private fun setWindowBlur(radiusPx: Int) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return
        if (radiusPx == lastWindowBlur || !supportsWindowBlur()) return
        lastWindowBlur = radiusPx
        window.setBackgroundBlurRadius(radiusPx)
    }
}
