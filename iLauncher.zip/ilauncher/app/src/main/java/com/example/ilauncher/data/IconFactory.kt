package com.example.ilauncher.data

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable

/**
 * Chuyển icon Android thành ảnh vuông "tràn viền" để sau đó cắt theo
 * hình squircle kiểu iOS (xem IosIconShape).
 */
object IconFactory {

    fun render(drawable: Drawable, sizePx: Int): Bitmap {
        val bitmap = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        if (drawable is AdaptiveIconDrawable) {
            // Layer adaptive rộng 108dp, vùng nhìn thấy 72dp => phóng 1.5 lần, lệch 1/4 mỗi cạnh
            val extra = sizePx / 4
            val l = -extra
            val t = -extra
            val r = sizePx + extra
            val b = sizePx + extra
            drawable.background?.let { it.setBounds(l, t, r, b); it.draw(canvas) }
            drawable.foreground?.let { it.setBounds(l, t, r, b); it.draw(canvas) }
        } else {
            // Icon cũ (không adaptive): đặt lên nền trắng như iOS
            canvas.drawColor(Color.WHITE)
            val pad = (sizePx * 0.14f).toInt()
            drawable.setBounds(pad, pad, sizePx - pad, sizePx - pad)
            drawable.draw(canvas)
        }
        return bitmap
    }
}
