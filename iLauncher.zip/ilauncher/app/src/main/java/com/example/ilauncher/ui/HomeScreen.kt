package com.example.ilauncher.ui

import android.graphics.Rect
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.coerceIn
import androidx.compose.ui.unit.dp
import com.example.ilauncher.LauncherUiState
import com.example.ilauncher.LauncherViewModel.Companion.COLUMNS
import com.example.ilauncher.LauncherViewModel.Companion.ROWS
import com.example.ilauncher.data.AppInfo

private val DockShape = RoundedCornerShape(34.dp)

@Composable
fun HomeScreen(
    state: LauncherUiState,
    pagerState: PagerState,
    onLaunch: (AppInfo, Rect?) -> Unit,
    onAppInfo: (AppInfo) -> Unit,
    onUninstall: (AppInfo) -> Unit,
    modifier: Modifier = Modifier,
) {
    // iPhone: icon 60pt trên màn rộng 390pt ≈ 15.5% chiều rộng
    val screenWidth = LocalConfiguration.current.screenWidthDp
    val iconSize = (screenWidth * 0.155f).dp.coerceIn(48.dp, 68.dp)

    Column(modifier.fillMaxSize().systemBarsPadding()) {
        Spacer(Modifier.height(12.dp))

        HorizontalPager(
            state = pagerState,
            beyondViewportPageCount = 1,
            modifier = Modifier.weight(1f).fillMaxWidth(),
        ) { page ->
            AppGridPage(
                apps = state.pages.getOrElse(page) { emptyList() },
                iconSize = iconSize,
                onLaunch = onLaunch,
                onAppInfo = onAppInfo,
                onUninstall = onUninstall,
            )
        }

        PageIndicator(
            count = pagerState.pageCount,
            current = pagerState.currentPage,
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
                .padding(vertical = 12.dp),
        )

        Dock(
            apps = state.dock,
            iconSize = iconSize,
            onLaunch = onLaunch,
            onAppInfo = onAppInfo,
            onUninstall = onUninstall,
        )
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun AppGridPage(
    apps: List<AppInfo>,
    iconSize: Dp,
    onLaunch: (AppInfo, Rect?) -> Unit,
    onAppInfo: (AppInfo) -> Unit,
    onUninstall: (AppInfo) -> Unit,
) {
    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        for (row in 0 until ROWS) {
            Row(
                modifier = Modifier.fillMaxWidth().weight(1f),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                for (col in 0 until COLUMNS) {
                    val app = apps.getOrNull(row * COLUMNS + col)
                    Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                        if (app != null) {
                            AppIcon(
                                app = app,
                                iconSize = iconSize,
                                showLabel = true,
                                onClick = { rect -> onLaunch(app, rect) },
                                onAppInfo = { onAppInfo(app) },
                                onUninstall = { onUninstall(app) },
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Dock kiểu iOS: khối bo tròn, nền "kính mờ" (trắng trong suốt + viền sáng).
 * Không có nhãn tên dưới icon.
 */
@Composable
private fun Dock(
    apps: List<AppInfo>,
    iconSize: Dp,
    onLaunch: (AppInfo, Rect?) -> Unit,
    onAppInfo: (AppInfo) -> Unit,
    onUninstall: (AppInfo) -> Unit,
) {
    Row(
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp)
            .clip(DockShape)
            .background(Color.White.copy(alpha = 0.22f))
            .border(0.5.dp, Color.White.copy(alpha = 0.25f), DockShape)
            .padding(vertical = 16.dp),
    ) {
        apps.forEach { app ->
            AppIcon(
                app = app,
                iconSize = iconSize,
                showLabel = false,
                onClick = { rect -> onLaunch(app, rect) },
                onAppInfo = { onAppInfo(app) },
                onUninstall = { onUninstall(app) },
            )
        }
    }
}

@Composable
private fun PageIndicator(count: Int, current: Int, modifier: Modifier = Modifier) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(9.dp),
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier.height(8.dp),
    ) {
        if (count > 1) {
            repeat(count) { index ->
                val alpha by animateFloatAsState(
                    targetValue = if (index == current) 1f else 0.38f,
                    label = "dot",
                )
                Box(
                    Modifier
                        .size(7.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = alpha))
                )
            }
        }
    }
}
