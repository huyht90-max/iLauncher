package com.example.ilauncher.system

import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import kotlin.math.roundToInt

/**
 * Cầu nối giữa Control Center và hệ thống Android.
 *
 * Lưu ý giới hạn của Android (không phải lỗi code):
 *  - Android 10+: app thường KHÔNG được bật/tắt Wi-Fi trực tiếp -> mở bảng Wi-Fi nổi của hệ thống.
 *  - Android 12+: bật/tắt Bluetooth trực tiếp bị hạn chế -> mở cài đặt Bluetooth.
 *  - Độ sáng hệ thống cần quyền "Sửa đổi cài đặt hệ thống" (WRITE_SETTINGS).
 */
class SystemControls(private val activity: Activity) {

    private val app = activity.applicationContext
    private val wifiManager = app.getSystemService(WifiManager::class.java)
    private val audioManager = app.getSystemService(AudioManager::class.java)
    private val cameraManager = app.getSystemService(CameraManager::class.java)
    private val connectivity = app.getSystemService(ConnectivityManager::class.java)
    private val bluetoothAdapter: BluetoothAdapter? =
        app.getSystemService(BluetoothManager::class.java)?.adapter

    // ---------- Wi-Fi ----------
    fun isWifiOn(): Boolean = runCatching { wifiManager.isWifiEnabled }.getOrDefault(false)

    @Suppress("DEPRECATION")
    fun toggleWifi() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            open(Intent(Settings.Panel.ACTION_WIFI))
        } else {
            runCatching { wifiManager.setWifiEnabled(!wifiManager.isWifiEnabled) }
        }
    }

    // ---------- Bluetooth ----------
    @SuppressLint("MissingPermission")
    fun isBluetoothOn(): Boolean =
        runCatching { bluetoothAdapter?.isEnabled == true }.getOrDefault(false)

    @SuppressLint("MissingPermission")
    @Suppress("DEPRECATION")
    fun toggleBluetooth() {
        val adapter = bluetoothAdapter ?: return
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            runCatching { if (adapter.isEnabled) adapter.disable() else adapter.enable() }
        } else {
            open(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
        }
    }

    // ---------- Internet / dữ liệu di động ----------
    fun isOnline(): Boolean = runCatching {
        val caps = connectivity.getNetworkCapabilities(connectivity.activeNetwork)
        caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
    }.getOrDefault(false)

    fun openInternetPanel() {
        open(
            Intent(
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) Settings.Panel.ACTION_INTERNET_CONNECTIVITY
                else Settings.ACTION_WIRELESS_SETTINGS
            )
        )
    }

    // ---------- Đèn pin ----------
    private val torchCameraId: String? = runCatching {
        cameraManager.cameraIdList.firstOrNull { id ->
            val c = cameraManager.getCameraCharacteristics(id)
            c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        }
    }.getOrNull()

    val hasTorch: Boolean get() = torchCameraId != null

    fun setTorch(on: Boolean) {
        val id = torchCameraId ?: return
        runCatching { cameraManager.setTorchMode(id, on) }
    }

    fun observeTorch(onChange: (Boolean) -> Unit): () -> Unit {
        val id = torchCameraId ?: return {}
        val callback = object : CameraManager.TorchCallback() {
            override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
                if (cameraId == id) onChange(enabled)
            }
        }
        cameraManager.registerTorchCallback(callback, Handler(Looper.getMainLooper()))
        return { cameraManager.unregisterTorchCallback(callback) }
    }

    // ---------- Độ sáng ----------
    fun canWriteSettings(): Boolean = Settings.System.canWrite(app)

    fun requestWriteSettings() {
        open(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${app.packageName}")))
    }

    fun getBrightness(): Float =
        Settings.System.getInt(app.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128) / 255f

    private var lastBrightness = -1

    fun setBrightness(value: Float) {
        if (!canWriteSettings()) return
        val level = (value * 255).roundToInt().coerceIn(1, 255)
        if (level == lastBrightness) return
        lastBrightness = level
        runCatching {
            val cr = app.contentResolver
            Settings.System.putInt(
                cr, Settings.System.SCREEN_BRIGHTNESS_MODE,
                Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL,
            )
            Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, level)
        }
    }

    // ---------- Âm lượng (media) ----------
    fun getVolume(): Float {
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        if (max == 0) return 0f
        return audioManager.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / max
    }

    fun setVolume(value: Float) {
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        runCatching {
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, (value * max).roundToInt(), 0)
        }
    }

    // ---------- Phím tắt ----------
    fun openCamera() = open(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
    fun openAlarms() = open(Intent(AlarmClock.ACTION_SHOW_ALARMS))
    fun openCalculator() = open(
        Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALCULATOR)
    )
    fun openSettings() = open(Intent(Settings.ACTION_SETTINGS))

    private fun open(intent: Intent): Boolean =
        runCatching { activity.startActivity(intent); true }.getOrDefault(false)
}
