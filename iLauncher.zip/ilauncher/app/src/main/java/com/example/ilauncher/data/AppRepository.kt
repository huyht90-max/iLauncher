package com.example.ilauncher.data

import android.content.Context
import android.content.Intent
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.graphics.Rect
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.UserHandle
import android.os.UserManager
import android.provider.MediaStore
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.Collator
import java.util.Locale

/** Đọc danh sách app đã cài, mở app, theo dõi cài/gỡ app. */
class AppRepository(private val context: Context) {

    private val launcherApps = context.getSystemService(LauncherApps::class.java)
    private val userManager = context.getSystemService(UserManager::class.java)
    private val iconSizePx = (context.resources.displayMetrics.density * 72).toInt()

    suspend fun loadApps(): List<AppInfo> = withContext(Dispatchers.Default) {
        val dpi = context.resources.displayMetrics.densityDpi
        val collator = Collator.getInstance(Locale.getDefault())

        userManager.userProfiles
            .flatMap { user -> launcherApps.getActivityList(null, user) }
            .filter { it.componentName.packageName != context.packageName }
            .map { info ->
                val drawable = info.getIcon(dpi) ?: context.packageManager.defaultActivityIcon
                AppInfo(
                    key = info.componentName.flattenToShortString() + "#" + info.user.hashCode(),
                    label = info.label?.toString().orEmpty(),
                    packageName = info.componentName.packageName,
                    component = info.componentName,
                    user = info.user,
                    icon = IconFactory.render(drawable, iconSizePx).asImageBitmap(),
                )
            }
            .sortedWith(compareBy(collator) { it.label })
    }

    /** Gói mặc định cho Dock: Điện thoại, Tin nhắn, Trình duyệt, Camera. */
    @Suppress("DEPRECATION")
    fun defaultDockPackages(): List<String> {
        val pm = context.packageManager
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")),
            Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA),
        )
        return intents.mapNotNull { intent ->
            pm.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
                ?.activityInfo?.packageName
                ?.takeIf { it != "android" } // "android" = hộp thoại chọn app, bỏ qua
        }
    }

    fun launch(app: AppInfo, sourceBounds: Rect?, options: Bundle?): Boolean = runCatching {
        launcherApps.startMainActivity(app.component, app.user, sourceBounds, options)
    }.isSuccess

    fun openAppInfo(app: AppInfo) {
        runCatching { launcherApps.startAppDetailsActivity(app.component, app.user, null, null) }
    }

    fun uninstall(app: AppInfo) {
        runCatching {
            context.startActivity(
                Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }

    /** Gọi [onChanged] mỗi khi có app được cài/gỡ/cập nhật. Trả về hàm huỷ đăng ký. */
    fun observeChanges(onChanged: () -> Unit): () -> Unit {
        val callback = object : LauncherApps.Callback() {
            override fun onPackageRemoved(packageName: String, user: UserHandle) = onChanged()
            override fun onPackageAdded(packageName: String, user: UserHandle) = onChanged()
            override fun onPackageChanged(packageName: String, user: UserHandle) = onChanged()
            override fun onPackagesAvailable(packageNames: Array<String>, user: UserHandle, replacing: Boolean) = onChanged()
            override fun onPackagesUnavailable(packageNames: Array<String>, user: UserHandle, replacing: Boolean) = onChanged()
        }
        launcherApps.registerCallback(callback, Handler(Looper.getMainLooper()))
        return { launcherApps.unregisterCallback(callback) }
    }
}
