package com.example.ilauncher.ui

import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.wifi.WifiManager
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.VolumeOff
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.Bluetooth
import androidx.compose.material.icons.rounded.Calculate
import androidx.compose.material.icons.rounded.FlashlightOff
import androidx.compose.material.icons.rounded.FlashlightOn
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.PhotoCamera
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.SignalCellularAlt
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.ProgressBarRangeInfo
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.progressBarRangeInfo
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LifecycleResumeEffect
import com.example.ilauncher.system.SystemControls
import com.example.ilauncher.ui.theme.IosBlue
import com.example.ilauncher.ui.theme.IosGreen

private val ModuleColor = Color.White.copy(alpha = 0.16f)
private val InactiveCircle = Color.White.copy(alpha = 0.20f)
private val ModuleShape = RoundedCornerShape(28.dp)

/**
 * Control Center phong cách iOS.
 * Hiển thị theo [ControlCenterState.progress]: mờ dần + trượt từ góc trên phải xuống.
 * Vuốt lên ở bất kỳ đâu hoặc chạm vùng trống để đóng.
 */
@Composable
fun ControlCenter(state: ControlCenterState, travelPx: Float) {
    val context = LocalContext.current
    val controls = remember(context) { SystemControls(context as Activity) }

    var wifiOn by remember { mutableStateOf(controls.isWifiOn()) }
    var bluetoothOn by remember { mutableStateOf(controls.isBluetoothOn()) }
    var online by remember { mutableStateOf(controls.isOnline()) }
    var torchOn by remember { mutableStateOf(false) }
    var brightness by remember { mutableFloatStateOf(controls.getBrightness()) }
    var volume by remember { mutableFloatStateOf(controls.getVolume()) }

    // Quay lại từ bảng Wi-Fi / Cài đặt -> đọc lại trạng thái
    LifecycleResumeEffect(Unit) {
        wifiOn = controls.isWifiOn()
        bluetoothOn = controls.isBluetoothOn()
        online = controls.isOnline()
        brightness = controls.getBrightness()
        volume = controls.getVolume()
        onPauseOrDispose { }
    }

    // Theo dõi Wi-Fi / Bluetooth / đèn pin thay đổi theo thời gian thực
    DisposableEffect(Unit) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context, intent: Intent) {
                wifiOn = controls.isWifiOn()
                bluetoothOn = controls.isBluetoothOn()
                online = controls.isOnline()
            }
        }
        val filter = IntentFilter().apply {
            addAction(WifiManager.WIFI_STATE_CHANGED_ACTION)
            addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
        }
        ContextCompat.registerReceiver(context, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        val stopTorch = controls.observeTorch { torchOn = it }
        onDispose {
            runCatching { context.unregisterReceiver(receiver) }
            stopTorch()
        }
    }

    val dragVelocity = remember { VelocityTracker() }
    val background = remember { MutableInteractionSource() }

    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            // chạm vùng trống -> đóng
            .clickable(interactionSource = background, indication = null) { state.close() }
            // vuốt lên -> đóng (kéo theo ngón tay)
            .pointerInput(travelPx) {
                detectVerticalDragGestures(
                    onDragStart = { dragVelocity.resetTracking() },
                    onDragEnd = { state.settle(dragVelocity.calculateVelocity().y / travelPx) },
                    onDragCancel = { state.settle(0f) },
                    onVerticalDrag = { change, dy ->
                        dragVelocity.addPosition(change.uptimeMillis, change.position)
                        state.dragBy(dy / travelPx)
                        change.consume()
                    },
                )
            },
    ) {
        val side = 22.dp
        val gap = 14.dp
        val unit = (maxWidth - side * 2 - gap * 3) / 4
        val big = unit * 2 + gap

        Column(
            verticalArrangement = Arrangement.spacedBy(gap),
            modifier = Modifier
                .statusBarsPadding()
                .padding(start = side, end = side, top = 36.dp)
                .graphicsLayer {
                    // đọc progress ở pha vẽ -> không recompose mỗi khung hình
                    val p = state.progress
                    alpha = p.coerceIn(0f, 1f)
                    translationY = -(1f - p) * 64.dp.toPx()
                    val s = 0.9f + 0.1f * p
                    scaleX = s
                    scaleY = s
                    transformOrigin = TransformOrigin(1f, 0f) // phóng ra từ góc trên phải
                },
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                // Khối kết nối 2x2
                Module(Modifier.size(big)) {
                    val btn = big * 0.34f
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.SpaceEvenly,
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                            RoundToggle(Icons.Rounded.SignalCellularAlt, online, IosGreen, "Internet", btn) {
                                controls.openInternetPanel()
                            }
                            RoundToggle(Icons.Rounded.Wifi, wifiOn, IosBlue, "Wi-Fi", btn) {
                                controls.toggleWifi()
                            }
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                            RoundToggle(Icons.Rounded.Bluetooth, bluetoothOn, IosBlue, "Bluetooth", btn) {
                                controls.toggleBluetooth()
                            }
                            RoundToggle(
                                icon = if (torchOn) Icons.Rounded.FlashlightOn else Icons.Rounded.FlashlightOff,
                                active = torchOn,
                                activeColor = Color.White,
                                label = "Đèn pin",
                                size = btn,
                                enabled = controls.hasTorch,
                            ) { controls.setTorch(!torchOn) }
                        }
                    }
                }

                // Thanh độ sáng
                VerticalSlider(
                    value = brightness,
                    icon = Icons.Rounded.LightMode,
                    label = "Độ sáng",
                    modifier = Modifier.size(width = unit, height = big),
                    canInteract = {
                        val ok = controls.canWriteSettings()
                        if (!ok) controls.requestWriteSettings() // xin quyền lần đầu
                        ok
                    },
                    onValueChange = { brightness = it; controls.setBrightness(it) },
                )

                // Thanh âm lượng
                VerticalSlider(
                    value = volume,
                    icon = if (volume <= 0.001f) Icons.AutoMirrored.Rounded.VolumeOff
                    else Icons.AutoMirrored.Rounded.VolumeUp,
                    label = "Âm lượng",
                    modifier = Modifier.size(width = unit, height = big),
                    onValueChange = { volume = it; controls.setVolume(it) },
                )
            }

            // Hàng phím tắt
            Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                ShortcutTile(Icons.Rounded.PhotoCamera, "Camera", unit) { controls.openCamera(); state.close() }
                ShortcutTile(Icons.Rounded.Alarm, "Báo thức", unit) { controls.openAlarms(); state.close() }
                ShortcutTile(Icons.Rounded.Calculate, "Máy tính", unit) { controls.openCalculator(); state.close() }
                ShortcutTile(Icons.Rounded.Settings, "Cài đặt", unit) { controls.openSettings(); state.close() }
            }
        }
    }
}

/** Khối nền mờ; nuốt chạm vào khoảng trống để không đóng Control Center. */
@Composable
private fun Module(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    Box(
        modifier = modifier
            .clip(ModuleShape)
            .background(ModuleColor)
            .pointerInput(Unit) { detectTapGestures { } },
        content = content,
    )
}

@Composable
private fun RoundToggle(
    icon: ImageVector,
    active: Boolean,
    activeColor: Color,
    label: String,
    size: Dp,
    enabled: Boolean = true,
    onClick: () -> Unit,
) {
    val bg by animateColorAsState(if (active) activeColor else InactiveCircle, label = "toggleBg")
    val tint by animateColorAsState(
        if (active && activeColor == Color.White) Color(0xFF1C1C1E) else Color.White,
        label = "toggleTint",
    )
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.88f else 1f, label = "toggleScale")

    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .size(size)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
                alpha = if (enabled) 1f else 0.4f
            }
            .clip(CircleShape)
            .background(bg)
            .clickable(
                interactionSource = interaction,
                indication = null,
                enabled = enabled,
                onClickLabel = label,
                role = Role.Switch,
                onClick = onClick,
            ),
    ) {
        Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(size * 0.46f))
    }
}

@Composable
private fun ShortcutTile(icon: ImageVector, label: String, size: Dp, onClick: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.88f else 1f, label = "tileScale")

    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .size(size)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(CircleShape)
            .background(ModuleColor)
            .clickable(
                interactionSource = interaction,
                indication = null,
                onClickLabel = label,
                role = Role.Button,
                onClick = onClick,
            ),
    ) {
        Icon(icon, contentDescription = label, tint = Color.White, modifier = Modifier.size(size * 0.42f))
    }
}

/** Thanh trượt dọc bo tròn kiểu iOS: phần trắng dâng lên từ đáy theo giá trị. */
@Composable
private fun VerticalSlider(
    value: Float,
    icon: ImageVector,
    label: String,
    onValueChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
    canInteract: () -> Boolean = { true },
) {
    val currentValue by rememberUpdatedState(value)
    val currentOnChange by rememberUpdatedState(onValueChange)
    val currentCanInteract by rememberUpdatedState(canInteract)
    var heightPx by remember { mutableFloatStateOf(1f) }

    Box(
        modifier = modifier
            .clip(ModuleShape)
            .background(ModuleColor)
            .onSizeChanged { heightPx = it.height.toFloat().coerceAtLeast(1f) }
            .pointerInput(Unit) {
                detectTapGestures { pos ->
                    if (currentCanInteract()) {
                        currentOnChange((1f - pos.y / heightPx).coerceIn(0f, 1f))
                    }
                }
            }
            .pointerInput(Unit) {
                var allowed = true
                var dragValue = 0f
                detectVerticalDragGestures(
                    onDragStart = {
                        allowed = currentCanInteract()
                        dragValue = currentValue
                    },
                    onVerticalDrag = { change, dy ->
                        change.consume() // không để vuốt trên slider đóng Control Center
                        if (allowed) {
                            dragValue = (dragValue - dy / heightPx).coerceIn(0f, 1f)
                            currentOnChange(dragValue)
                        }
                    },
                )
            }
            .semantics {
                contentDescription = label
                progressBarRangeInfo = ProgressBarRangeInfo(value, 0f..1f)
            },
    ) {
        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .fillMaxHeight(value.coerceIn(0f, 1f))
                .background(Color.White)
        )
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (value > 0.16f) Color(0xFF5A5A5E) else Color.White,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 18.dp)
                .size(26.dp),
        )
    }
}
