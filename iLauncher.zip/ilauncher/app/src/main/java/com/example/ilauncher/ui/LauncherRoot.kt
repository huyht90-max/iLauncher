package com.example.ilauncher.ui

import android.app.ActivityOptions
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerInputScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ilauncher.LauncherViewModel
import com.example.ilauncher.data.AppInfo
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

@Composable
fun LauncherRoot(
    homeEvents: Flow<Unit>,
    windowBlurSupported: Boolean,
    onWindowBlur: (Int) -> Unit,
    vm: LauncherViewModel = viewModel(),
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val pagerState = rememberPagerState(pageCount = { state.pages.size.coerceAtLeast(1) })
    val cc = rememberControlCenterState()
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val view = LocalView.current
    val density = LocalDensity.current

    // Quãng kéo tương ứng progress 0 -> 1
    val travelPx = with(density) { (LocalConfiguration.current.screenHeightDp.dp * 0.45f).toPx() }
    // Vùng nóng: nửa phải màn hình, từ mép trên xuống dưới thanh trạng thái ~90dp
    val hotZoneBottomPx = WindowInsets.statusBars.getTop(density) + with(density) { 90.dp.toPx() }
    val maxWindowBlurPx = with(density) { 40.dp.toPx() }

    val ccVisible by remember { derivedStateOf { cc.progress > 0.001f } }

    // Nút Home khi đang ở launcher: đóng Control Center hoặc về trang đầu
    LaunchedEffect(Unit) {
        homeEvents.collect {
            when {
                cc.progress > 0f -> cc.close()
                pagerState.currentPage != 0 -> pagerState.animateScrollToPage(0)
                else -> Unit
            }
        }
    }

    // Launcher không bao giờ được "thoát" bằng nút Back
    BackHandler {
        if (cc.progress > 0f) cc.close()
        else scope.launch { pagerState.animateScrollToPage(0) }
    }

    // Đồng bộ độ mờ hình nền (cửa sổ) theo progress, làm tròn để không gọi quá dày
    LaunchedEffect(cc) {
        snapshotFlow { (cc.progress.coerceIn(0f, 1f) * maxWindowBlurPx / 4f).roundToInt() * 4 }
            .collect { onWindowBlur(it) }
    }

    val launchApp: (AppInfo, android.graphics.Rect?) -> Unit = { app, rect ->
        // Hiệu ứng phóng to từ vị trí icon (giống iOS mở app)
        val options = rect?.let {
            ActivityOptions.makeScaleUpAnimation(view, it.left, it.top, it.width(), it.height()).toBundle()
        }
        if (!vm.launch(app, rect, options)) {
            Toast.makeText(context, "Không mở được ${app.label}", Toast.LENGTH_SHORT).show()
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(travelPx, hotZoneBottomPx) {
                detectTopRightPull(hotZoneBottomPx, travelPx, cc)
            }
    ) {
        HomeScreen(
            state = state,
            pagerState = pagerState,
            onLaunch = launchApp,
            onAppInfo = vm::openAppInfo,
            onUninstall = vm::uninstall,
            modifier = Modifier.graphicsLayer {
                val p = cc.progress.coerceIn(0f, 1f)
                val s = 1f - 0.05f * p
                scaleX = s
                scaleY = s
                // Làm mờ lưới icon + dock khi Control Center mở (Android 12+)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    val r = p * 30.dp.toPx()
                    renderEffect = if (r > 0.5f) BlurEffect(r, r, TileMode.Decal) else null
                }
            },
        )

        // Lớp tối phủ lên; đậm hơn nếu máy không hỗ trợ làm mờ hình nền
        Box(
            Modifier
                .fillMaxSize()
                .graphicsLayer { alpha = cc.progress.coerceIn(0f, 1f) }
                .background(Color.Black.copy(alpha = if (windowBlurSupported) 0.28f else 0.55f))
        )

        if (ccVisible) {
            ControlCenter(state = cc, travelPx = travelPx)
        }
    }
}

/**
 * Nhận cử chỉ vuốt xuống bắt đầu ở góc trên bên phải.
 * Dùng PointerEventPass.Initial để "chặn" trước lưới icon/pager — nhưng chỉ khi
 * chắc chắn là vuốt dọc xuống; chạm hoặc vuốt ngang vẫn đi xuống bên dưới bình thường.
 */
private suspend fun PointerInputScope.detectTopRightPull(
    hotZoneBottomPx: Float,
    travelPx: Float,
    state: ControlCenterState,
) {
    awaitEachGesture {
        val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
        if (state.progress > 0f) return@awaitEachGesture
        if (down.position.x < size.width * 0.5f || down.position.y > hotZoneBottomPx) {
            return@awaitEachGesture
        }

        val slop = viewConfiguration.touchSlop
        val tracker = VelocityTracker()
        tracker.addPosition(down.uptimeMillis, down.position)
        var dragging = false
        var dx = 0f
        var dy = 0f

        while (true) {
            val event = awaitPointerEvent(PointerEventPass.Initial)
            val change = event.changes.firstOrNull { it.id == down.id } ?: break
            if (!change.pressed) break
            val delta = change.positionChange()
            tracker.addPosition(change.uptimeMillis, change.position)

            if (!dragging) {
                dx += delta.x
                dy += delta.y
                if (dy > slop && dy > abs(dx)) {
                    dragging = true
                    state.dragBy(dy / travelPx)
                    change.consume()
                } else if (abs(dx) > slop || dy < -slop) {
                    return@awaitEachGesture // vuốt ngang/lên: nhường cho pager
                }
            } else {
                state.dragBy(delta.y / travelPx)
                change.consume()
            }
        }

        if (dragging) state.settle(tracker.calculateVelocity().y / travelPx)
    }
}
