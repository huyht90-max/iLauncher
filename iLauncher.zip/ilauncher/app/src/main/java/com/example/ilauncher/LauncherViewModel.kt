package com.example.ilauncher

import android.app.Application
import android.graphics.Rect
import android.os.Bundle
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ilauncher.data.AppInfo
import com.example.ilauncher.data.AppRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class LauncherUiState(
    val loading: Boolean = true,
    val pages: List<List<AppInfo>> = emptyList(),
    val dock: List<AppInfo> = emptyList(),
)

class LauncherViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = AppRepository(application)
    private val _state = MutableStateFlow(LauncherUiState())
    val state: StateFlow<LauncherUiState> = _state.asStateFlow()

    private var loadJob: Job? = null
    private val unregister: () -> Unit = repo.observeChanges { refresh(debounce = true) }

    init {
        refresh()
    }

    fun refresh(debounce: Boolean = false) {
        loadJob?.cancel()
        loadJob = viewModelScope.launch {
            if (debounce) delay(300) // gộp nhiều sự kiện cài/gỡ liên tiếp
            val apps = repo.loadApps()
            val dockPackages = withContext(Dispatchers.Default) { repo.defaultDockPackages() }

            val preferred = dockPackages
                .mapNotNull { pkg -> apps.firstOrNull { it.packageName == pkg } }
                .distinctBy { it.key }
            val dock = (preferred + apps.filterNot { a -> preferred.any { it.key == a.key } })
                .take(DOCK_SIZE)
            val dockKeys = dock.map { it.key }.toSet()

            _state.value = LauncherUiState(
                loading = false,
                pages = apps.filterNot { it.key in dockKeys }.chunked(APPS_PER_PAGE),
                dock = dock,
            )
        }
    }

    fun launch(app: AppInfo, bounds: Rect?, options: Bundle?): Boolean =
        repo.launch(app, bounds, options)

    fun openAppInfo(app: AppInfo) = repo.openAppInfo(app)
    fun uninstall(app: AppInfo) = repo.uninstall(app)

    override fun onCleared() {
        unregister()
    }

    companion object {
        const val DOCK_SIZE = 4
        const val COLUMNS = 4
        const val ROWS = 6
        const val APPS_PER_PAGE = COLUMNS * ROWS
    }
}
