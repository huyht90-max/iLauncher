package com.example.ilauncher.ui

import androidx.compose.animation.core.animate
import androidx.compose.animation.core.spring
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/**
 * Trạng thái mở của Control Center: progress = 0 (đóng) .. 1 (mở hẳn).
 * Ngón tay kéo trực tiếp progress; khi thả tay thì "lò xo" về 0 hoặc 1.
 */
@Stable
class ControlCenterState(private val scope: CoroutineScope) {

    var progress by mutableFloatStateOf(0f)
        private set

    private var animJob: Job? = null

    fun dragBy(delta: Float) {
        animJob?.cancel()
        progress = (progress + delta).coerceIn(0f, 1f)
    }

    /** @param velocity vận tốc tính theo "progress mỗi giây" (dương = kéo xuống). */
    fun settle(velocity: Float) {
        val target = when {
            velocity > 1.2f -> 1f
            velocity < -1.2f -> 0f
            progress > 0.45f -> 1f
            else -> 0f
        }
        animateTo(target, velocity)
    }

    fun open() = animateTo(1f, 0f)
    fun close() = animateTo(0f, 0f)

    private fun animateTo(target: Float, velocity: Float) {
        animJob?.cancel()
        animJob = scope.launch {
            animate(
                initialValue = progress,
                targetValue = target,
                initialVelocity = velocity,
                animationSpec = spring(
                    dampingRatio = if (target == 1f) 0.82f else 1f,
                    stiffness = 380f,
                ),
            ) { value, _ -> progress = value.coerceAtLeast(0f) }
        }
    }
}

@Composable
fun rememberControlCenterState(): ControlCenterState {
    val scope = rememberCoroutineScope()
    return remember { ControlCenterState(scope) }
}
