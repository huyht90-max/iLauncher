# iLauncher — Android Launcher phong cách iOS (Kotlin + Jetpack Compose)

## Tính năng
- **Launcher mặc định**: `MAIN` + `HOME` + `DEFAULT` trong `AndroidManifest.xml`.
- **Home Screen**: lưới 4×6 icon squircle kiểu iOS, vuốt ngang chuyển trang (`HorizontalPager`), chấm chỉ trang.
- **Dock** cố định tối đa 4 app (ưu tiên Điện thoại, Tin nhắn, Trình duyệt, Camera), nền kính mờ.
- **Nhấn giữ icon**: menu Thông tin ứng dụng / Gỡ ứng dụng. Nhấn icon: thu nhỏ có lò xo, mở app với hiệu ứng phóng từ icon.
- **Control Center**: vuốt xuống từ góc trên bên phải (ngay dưới thanh trạng thái). Có Wi-Fi, Bluetooth, Internet, Đèn pin, thanh Độ sáng, thanh Âm lượng, phím tắt Camera / Báo thức / Máy tính / Cài đặt. Kéo theo ngón tay, thả ra bật lò xo; vuốt lên hoặc chạm vùng trống để đóng.
- **Blur**: Android 12+ làm mờ lưới icon (`RenderEffect`) và hình nền (`Window.setBackgroundBlurRadius`). Máy cũ hơn: lớp tối thay thế.
- Tự cập nhật khi cài/gỡ app; nút Home đóng Control Center hoặc về trang 1; nút Back không thoát launcher.

## Cấu trúc
```
app/src/main/java/com/example/ilauncher/
├── MainActivity.kt            Activity Home, edge-to-edge, blur cửa sổ
├── LauncherViewModel.kt       Danh sách app, chia trang, chọn Dock
├── data/                      AppInfo, AppRepository (LauncherApps), IconFactory
├── system/SystemControls.kt   Wi-Fi, Bluetooth, đèn pin, độ sáng, âm lượng
└── ui/                        LauncherRoot, HomeScreen, AppIcon, ControlCenter(+State)
```

## Build APK chỉ bằng điện thoại (GitHub Actions)
1. Tạo repo mới trên github.com, chọn **Add file → Upload files**, kéo toàn bộ nội dung đã giải nén (giữ cả thư mục `.github`).
2. Vào tab **Actions** → workflow **Build APK** sẽ tự chạy (hoặc bấm *Run workflow*).
3. Chạy xong (~5–8 phút), mở lần chạy → mục **Artifacts** → tải `iLauncher-debug` → giải nén, cài APK.

> Lưu ý: GitHub đôi khi ẩn thư mục bắt đầu bằng dấu chấm khi upload qua web. Nếu tab Actions trống, tạo file
> `.github/workflows/build.yml` bằng **Add file → Create new file** và dán nội dung từ file trong zip.

Với Android Studio: mở thư mục gốc, bấm Run.

## Đặt làm launcher mặc định
Cài đặt → Ứng dụng → Ứng dụng mặc định → **Ứng dụng màn hình chính** → chọn iLauncher.
(Samsung: Cài đặt → Ứng dụng → Chọn ứng dụng mặc định → Ứng dụng màn hình chính.)

## Giới hạn do Android (không phải lỗi)
- **Wi-Fi** (Android 10+) và **Bluetooth** (Android 12+): app thường không được bật/tắt trực tiếp → nút mở bảng/cài đặt của hệ thống; trạng thái vẫn hiện đúng.
- **Độ sáng**: lần đầu chạm thanh trượt sẽ mở màn hình cấp quyền *Sửa đổi cài đặt hệ thống*.
- **Blur hình nền** phụ thuộc máy (có thể tắt khi tiết kiệm pin). Dock dùng hiệu ứng kính mờ giả lập; muốn blur thật cho Dock có thể thêm thư viện Haze (`dev.chrisbanes.haze`).
- Vùng thanh trạng thái thuộc hệ thống, nên hãy bắt đầu vuốt ngay **dưới** thanh trạng thái ở nửa phải màn hình.
